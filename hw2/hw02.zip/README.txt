HW02: procedural shader
The idea was to get the wave equation on a two dimensional surface to wrok by changing the color

how to run
run commands
-qmake hw02.pro
-make
-./hw02


 
took about 7 hours getting the bessel function to work. 
First, I had a lack of ideas at first an tried messing about with perlin noise. 
Also, I was overthinking the problem with the wave equation and tried to make a realistic model
but what I needed was to recallibrate the center which the idea came from shadertoy.
Then I added another parameter to have more than the simple ringed convergance.
then I added a rendom division which makes an interesting looking result which I kept as the final product




storage of all the trash code in fragment shader
