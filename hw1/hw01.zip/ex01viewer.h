#ifndef EX01V_H
#define EX01V_H

#include <QWidget>

class Ex01viewer : public QWidget
{
Q_OBJECT
public:
    Ex01viewer();
};

#endif
